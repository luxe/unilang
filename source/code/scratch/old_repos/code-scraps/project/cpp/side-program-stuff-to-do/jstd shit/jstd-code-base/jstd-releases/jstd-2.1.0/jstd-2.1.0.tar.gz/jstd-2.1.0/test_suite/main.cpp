#include <iostream>
#include <string>
#include <cstdlib>
#include <algorithm>
#include "../jstd-export/built/jstd.hpp"

int main(){
	using namespace jstd;
	std::string str = "THE";
	
	//return EXIT_SUCCESS;
}
