#pragma once
#include "program_options.hpp"

class Documenter{
	
public:
	static void Document(Program_Options const& program_options);
private:

};