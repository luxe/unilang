#pragma once
#include "stat_timer.hpp"

class Build_Stats: public Stat_Timer{
	
	
public:
	
	//constructor

private:
	

};