#include "global.hpp"
unsigned long long include_gaurd_global = 0;
unsigned long long pragma_unique_maker_global = 0;